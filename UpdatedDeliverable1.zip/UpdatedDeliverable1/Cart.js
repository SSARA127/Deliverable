document.addEventListener("DOMContentLoaded", function() {
    let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];
    const cartContainer = document.querySelector('.container-products');
    updateCartCount();
    updateTotalPriceUI();
    renderProducts();
    let savedCartItems = sessionStorage.getItem('cartItems');
    if (savedCartItems) {
        cartItems = JSON.parse(savedCartItems);
    } else {
        cartItems = [];
    }
    document.querySelectorAll('#clearall').forEach(button => {
        button.addEventListener('click', function() {
            clearAll();
        });
    });
    document.querySelectorAll('#checkout').forEach(button => {
        button.addEventListener('click', function() {
            checkout();
        });
    });
    function updateCartCount() {
        const cartCountElement = document.getElementById('cart-count');
        if (cartCountElement) {
            cartCountElement.textContent =aggregateItems(cartItems).length ;
        }
    }
    function updateCartUI() {
        const productsContainer = document.createElement('div');
        productsContainer.innerHTML = '';
        cartItems.forEach(item => {
            const productCard = document.createElement('div');
            productCard.classList.add('product-card');
            productCard.innerHTML = `
                 <h2>${item.name}</h2>
                <p>Price: £${item.price}</p>
                <p>Quantity: ${item.quantity}</p>
            `;
            console.log(productCard);
            productsContainer.innerHTML = '';
            productsContainer.appendChild(productCard);
        });
        const cartCountElement = document.getElementById('cart-count')||sessionStorage.getItem('cart-count');
        if (cartCountElement) {
            cartCountElement.textContent = aggregateItems(cartItems).length;
            sessionStorage.setItem('cart-count', aggregateItems(cartItems).length);
        }
    }
    function clearAll() {
        cartItems = [];
        sessionStorage.removeItem('cartItems');
        alert('Cleared All Cart');
        renderProducts();
        updateTotalPriceUI();
        updateCartUI();
    }
    function checkout() {
        alert('Checkout process initiated!');
    }
    function calculateTotalPrice() {
        let totalPrice = 0;
        cartItems.forEach(item => {
            totalPrice += item.price;
        });
        return totalPrice;
    }
    function updateTotalPriceUI() {
        const totalPrice = calculateTotalPrice();
        const totalPriceElement = document.getElementById('total-price');
        if (totalPriceElement) {
            totalPriceElement.textContent = `Total Price: £${totalPrice.toFixed(2)}`;
        }
    }

    function aggregateItems(cartItems) {
        const aggregated = {};
        cartItems.forEach(item => {
            if (aggregated[item.name]) {
                aggregated[item.name].quantity ++;
            } else {
                aggregated[item.name] = { ...item };
            }
        });
        cartItems.forEach(item => {
            aggregated[item.name].price =item.price*aggregated[item.name].quantity;
        });
        return Object.values(aggregated);
    }
    function renderProducts() {
        const cartContainer = document.querySelector('.container-products');
        if (!cartContainer) {
            console.error('#container-products not found.');
            return;
        }
        let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];
        let aggregatedItems = aggregateItems(cartItems);
        sessionStorage.setItem('aggregatedItems',JSON.stringify(aggregatedItems));
        cartContainer.innerHTML = '';

        const products = [
            { name: 'Chicken Biriyani', image: 'img/img1.jpg', quantity: 2, price: '£7.50' },
            { name: 'Chicken Fried Rice', image: 'img/img2.jpg', quantity: 2, price: '£6.50' },
            { name: 'Grilled Chicken', image: 'img/img3.jpg', quantity: 2, price: '£12.00' },
            { name: 'Pepper Chicken', image: 'img/img4.jpg', quantity: 2, price: '£6.00' },
            { name: 'Chilli Fish', image: 'img/img5.jpg', quantity: 2, price: '£8.00' },
            { name: 'Mutton Sukka', image: 'img/img6.jpg', quantity: 2, price: '£9.00' },
            { name: 'Butter Garlic Prawns', image: 'img/img7.jpg', quantity: 2, price: '£13.00' },
            { name: 'Seafood Noodles', image: 'img/img8.jpg', quantity: 2, price: '£7.50' },
            { name: 'Kashmiri Chilli Powder', image: 'img/img9.jpg', quantity: 2, price: '£2.50' },
            { name: 'Garam masala', image: 'img/img10.jpg', quantity: 2, price: '£2.50' },
            { name: 'Pepper Powder', image: 'img/img11.jpg', quantity: 2, price: '£3.00' },
            { name: 'Chicken Masala', image: 'img/img12.jpg', quantity: 2, price: '£2.00' },
            { name: 'Coriander Powder', image: 'img/img13.jpg', quantity: 2, price: '£2.00' },
            { name: 'Ginger Garlic Paste', image: 'img/img14.jpg', quantity: 2, price: '£1.50' },
            { name: 'Turmeric Powder', image: 'img/img15.jpg', quantity: 2, price: '£2.00' },
            { name: 'Biriyani Masala', image: 'img/img16.jpg', quantity: 2, price: '£2.50' },
            { name: 'Pepper Powder', image: 'img/img1.jpg', quantity: 2, price: '£7.50' },
        ];

        aggregatedItems.forEach(item => {
            const matchingProduct = products.find(product => product.name === item.name);

            if (matchingProduct) {
                const productItem = document.createElement('div');
                productItem.classList.add('product-item');

                productItem.innerHTML = `
                <div class="product-image">
                    <img src="${matchingProduct.image}" alt="${item.name}">
                </div>
                <div class="product-details">
                    <h4 class="product-title">${item.name}</h4>
                    <button class="decrease-quantity" data-item-name="${item.name}">-</button>
                    <p class="product-quantity">Quantity: ${item.quantity}</p>
                    <button class="increase-quantity" data-item-name="${item.name}">+</button>
                </div>
                <div class="product-price">£${item.price.toFixed(2)}</div>
            `;
                cartContainer.appendChild(productItem);

            }
        });
    }

    cartContainer.addEventListener('click', function(event) {
        const target = event.target;

        if (target.classList.contains('decrease-quantity')) {
            const itemName = target.getAttribute('data-item-name');
            const item = cartItems.find(i => i.name === itemName);
            if (item) {
                updateCartItem(item, "decrease");
            }
        }

        else if (target.classList.contains('increase-quantity')) {
            const itemName = target.getAttribute('data-item-name');
            const item = cartItems.find(i => i.name === itemName);
            if (item) {
                updateCartItem(item, "increase");
            }
        }
    });

    function updateCartItem(updatedItem,process) {
        const itemIndex = cartItems.findIndex(item => item.name === updatedItem.name);
        console.log(cartItems);
        if (itemIndex !== -1) {
            if(process==="increase") {
                const newItem = {
                    name: cartItems[itemIndex].name,
                    price: cartItems[itemIndex].price,
                    quantity: 1
                };
                cartItems.push(newItem);
            }
            else {
                for (let i = cartItems.length - 1; i >= 0; i--) {
                    if (cartItems[i].name === updatedItem.name) {
                        cartItems.splice(i, 1);
                        break;
                    }
                }
            }
            sessionStorage.setItem('cartItems', JSON.stringify(cartItems));
            console.log(cartItems);
            updateCartCount();
            renderProducts();
            updateTotalPriceUI();
            updateCartCount();
        }
    }


});
